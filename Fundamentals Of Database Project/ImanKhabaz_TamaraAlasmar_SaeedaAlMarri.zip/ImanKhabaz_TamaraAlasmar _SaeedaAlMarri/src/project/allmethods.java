package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JOptionPane;
/*
 * Tamara Alasmar – 202103791
 * Saeeda Al-Marri – 202106704
 * Iman Khabaz –   202206112
 */

public class allmethods {
	Connection conn;
	PreparedStatement stmt;
	
	public allmethods() {
		try {
			conn = DriverManager.getConnection("jdbc:oracle:thin:@coestudb.qu.edu.qa:1521/STUD.qu.edu.qa","ik2206112", "ik2206112"); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void close() {
		try {
			conn.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public void addcust(int Customer_ID, String CName, int Age, String Sex, int Mobile_no, int Work_no, int Home_no, int AId, String Link_) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO cust2 (Customer_ID, CName, Age, Sex, Mobile_no, Work_no, Home_no, AId, Link_) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            stmt.setInt(1, Customer_ID);
            stmt.setString(2, CName);
            stmt.setInt(3, Age);
            stmt.setString(4, Sex);
            stmt.setInt(5, Mobile_no);
            stmt.setInt(6, Work_no);
            stmt.setInt(7, Home_no);
            stmt.setInt(8, AId);
            stmt.setString(9, Link_);
            int rs = stmt.executeUpdate();
            if(rs>0) {
            makeReservation r = new makeReservation();
            r.setVisible(true);}
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
    public void addReservation(int Reserve_no, int AId, int Package_no) {
        try {
            PreparedStatement stmt1 = conn.prepareStatement("insert into Reservation (Reserve_Status , Reserve_no , AId , Package_no) values ('CONFIRMED' , ? , ? , ?)");
            stmt1.setInt(1, Reserve_no);
            stmt1.setInt(2, AId);
            stmt1.setDouble(3, Package_no);
            int rs1 = stmt1.executeUpdate();
            PreparedStatement stmt2 = conn.prepareStatement("insert into Make (AId , Reserve_no) values (? , ?)");
            stmt2.setInt(1, AId);
            stmt2.setInt(2,Reserve_no);
            int rs2 = stmt2.executeUpdate();
            if(rs1 > 0 && rs2>0) {
				JOptionPane.showMessageDialog(null, "Customer and his/her Reservation added successfully.");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
	public void deleteCustomer(int customerId) {
		String deleteCustomerSQL = "delete from cust2 where Customer_ID = ?";
		String updateReservationsSQL = "update Reservation set Reserve_Status='CANCELLED'  where AId = (select AId from cust2 where Customer_ID=?) "; 

		try (   PreparedStatement stmtCustomer = conn.prepareStatement(deleteCustomerSQL);
				PreparedStatement stmtReservations = conn.prepareStatement(updateReservationsSQL);
				 )
		{
			stmtCustomer.setInt(1, customerId);
			stmtReservations.setInt(1, customerId);

			// Execute
			int rs1 = stmtReservations.executeUpdate();
			int rs2 = stmtCustomer.executeUpdate();
			if(rs1 > 0 && rs2>0) {
					JOptionPane.showMessageDialog(null, "Customer and his/her Reservation removed successfully.");
	            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	    
	
    public void updatecust(int customerID,String CName, int Age, String Sex, int Mobile_no, int Work_no, int Home_no, int AId, String Link_) {
    	String sql = "UPDATE cust2 SET CName = ?, Age = ?, Sex = ?, Mobile_no = ?, Work_no = ?, Home_no = ?, AId = ?, Link_ = ? WHERE Customer_ID = ?";  
    	try {
        PreparedStatement stmt = conn.prepareStatement(sql) ;
        stmt.setString(1, CName);
        stmt.setInt(2, Age);
        stmt.setString(3, Sex);
        stmt.setInt(4, Mobile_no);
        stmt.setInt(5, Work_no);
        stmt.setInt(6, Home_no);
        stmt.setInt(7, AId);
        stmt.setString(8, Link_);
        stmt.setInt(9, customerID);

        int rs = stmt.executeUpdate();
        if(rs>0) 
			JOptionPane.showMessageDialog(null, "Customer Information Updated Successfully.");

        
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addTrip(int startTime, int duration, String destination, double price, String tripDate, int tripno,String location, String site, String landmarks, int packageNo) {
        try {
            PreparedStatement stmt = conn.prepareStatement("insert into Tour_Trip (Start_time, Duration, Destination, Price, Trip_date, Trip_no,Location_, Site_, Landmarks, Package_no) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            stmt.setInt(1, startTime);
            stmt.setInt(2, duration);
            stmt.setString(3, destination);
            stmt.setDouble(4, price);
            stmt.setString(5, tripDate);
            stmt.setInt(6, tripno);
            stmt.setString(7, location);
            stmt.setString(8, site);
            stmt.setString(9, landmarks);
            stmt.setInt(10, packageNo);
            int rs = stmt.executeUpdate();
            if(rs>0) {
            	JOptionPane.showMessageDialog(null, "Trip Added Successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateTrip(int NewstartTime, int Newduration, String Newdestination, double Newprice, String NewtripDate, int tripno,String Newlocation, String Newsite, String Newlandmarks, int NewpackageNo) {
        try {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Tour_Trip SET Start_time=?, Duration=?, Destination=?, Price=?, Trip_date=? ,Location_=?,Site_=?,Landmarks=?,Package_no=?  WHERE Trip_no=?");
            stmt.setInt(1, NewstartTime);
            stmt.setInt(2, Newduration);
            stmt.setString(3, Newdestination);
            stmt.setDouble(4, Newprice);
            stmt.setString(5, NewtripDate);
            stmt.setString(6, Newlocation);
            stmt.setString(7, Newsite);
            stmt.setString(8, Newlandmarks);
            stmt.setInt(9, NewpackageNo);
            stmt.setInt(10, tripno);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) 
            	JOptionPane.showMessageDialog(null, "Trip Updated Successfully.");
           
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

}

	
    




