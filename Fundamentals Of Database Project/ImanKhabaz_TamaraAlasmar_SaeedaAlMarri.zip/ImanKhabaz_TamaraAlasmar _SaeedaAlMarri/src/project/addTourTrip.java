package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.awt.event.ActionEvent;

/*
 * Tamara Alasmar – 202103791
 * Saeeda Al-Marri – 202106704
 * Iman Khabaz –   202206112
 */

public class addTourTrip extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField STtextField;
	private JTextField DtextField;
	private JTextField DestextField;
	private JTextField PtextField;
	private JTextField DatetextField;
	private JTextField TNotextField;
	private JTextField LtextField;
	private JTextField StextField;
	private JTextField LandtextField;
	private JTextField PkNotextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addTourTrip frame = new addTourTrip();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void display() {
		try {
			addTourTrip frame = new addTourTrip();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public addTourTrip() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 529, 371);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Adding a new Tour Trip");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel.setBounds(111, 0, 289, 69);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Enter the Information of the Trip");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(137, 60, 263, 27);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Start time");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(10, 111, 79, 14);
		contentPane.add(lblNewLabel_2);
		
		STtextField = new JTextField();
		STtextField.setBounds(99, 106, 96, 20);
		contentPane.add(STtextField);
		STtextField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Duration");
		lblNewLabel_3.setBounds(10, 141, 49, 14);
		contentPane.add(lblNewLabel_3);
		
		DtextField = new JTextField();
		DtextField.setBounds(99, 138, 96, 20);
		contentPane.add(DtextField);
		DtextField.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Destination");
		lblNewLabel_4.setBounds(10, 177, 79, 14);
		contentPane.add(lblNewLabel_4);
		
		DestextField = new JTextField();
		DestextField.setBounds(99, 174, 96, 20);
		contentPane.add(DestextField);
		DestextField.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Price");
		lblNewLabel_5.setBounds(10, 208, 49, 14);
		contentPane.add(lblNewLabel_5);
		
		PtextField = new JTextField();
		PtextField.setBounds(99, 205, 96, 20);
		contentPane.add(PtextField);
		PtextField.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Trip Date");
		lblNewLabel_6.setBounds(10, 238, 79, 14);
		contentPane.add(lblNewLabel_6);
		
		DatetextField = new JTextField();
		DatetextField.setBounds(99, 235, 96, 20);
		contentPane.add(DatetextField);
		DatetextField.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Trip Number");
		lblNewLabel_7.setBounds(242, 111, 114, 14);
		contentPane.add(lblNewLabel_7);
		
		TNotextField = new JTextField();
		TNotextField.setBounds(370, 108, 96, 20);
		contentPane.add(TNotextField);
		TNotextField.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Location");
		lblNewLabel_8.setBounds(242, 141, 70, 14);
		contentPane.add(lblNewLabel_8);
		
		LtextField = new JTextField();
		LtextField.setBounds(370, 138, 96, 20);
		contentPane.add(LtextField);
		LtextField.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Site");
		lblNewLabel_9.setBounds(242, 180, 49, 14);
		contentPane.add(lblNewLabel_9);
		
		StextField = new JTextField();
		StextField.setBounds(370, 174, 96, 20);
		contentPane.add(StextField);
		StextField.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("Landmark");
		lblNewLabel_10.setBounds(242, 208, 89, 14);
		contentPane.add(lblNewLabel_10);
		
		LandtextField = new JTextField();
		LandtextField.setBounds(370, 205, 96, 20);
		contentPane.add(LandtextField);
		LandtextField.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("Package Number");
		lblNewLabel_11.setBounds(242, 238, 114, 14);
		contentPane.add(lblNewLabel_11);
		
		PkNotextField = new JTextField();
		PkNotextField.setBounds(370, 235, 96, 20);
		contentPane.add(PkNotextField);
		PkNotextField.setColumns(10);
		
		//Enter Button
		JButton btnNewButton = new JButton("Enter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				allmethods allM = new allmethods();
				int starttime = Integer.parseInt(STtextField.getText());
				int duration = Integer.parseInt(STtextField.getText());
				double price = Double.parseDouble(PtextField.getText());
				int tripno = Integer.parseInt(TNotextField.getText());
				int packageno = Integer.parseInt(PkNotextField.getText());
				allM.addTrip(starttime,duration,DestextField.getText() , price, DatetextField.getText(),tripno, LtextField.getText(), StextField.getText(), LandtextField.getText(), packageno);
			}
		});
		btnNewButton.setBounds(106, 284, 89, 23);
		contentPane.add(btnNewButton);
		
		//Reset Button
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				STtextField.setText("");
				DtextField.setText("");
				DestextField.setText("");
				PtextField.setText("");
				DatetextField.setText("");
				TNotextField.setText("");
				LtextField.setText("");
				StextField.setText("");
				LandtextField.setText("");
				PkNotextField.setText("");

			}
		});
		btnNewButton_1.setBounds(223, 284, 89, 23);
		contentPane.add(btnNewButton_1);
		
		//Exit Button
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_2.setBounds(354, 284, 89, 23);
		contentPane.add(btnNewButton_2);
		
		
	}

}
