package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/*
 * Tamara Alasmar – 202103791
 * Saeeda Al-Marri – 202106704
 * Iman Khabaz –   202206112
 */

public class addcust extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_CName;
	private JTextField textField_CID;
	private JTextField textField_CAge;
	private JTextField textField_CSex;
	private JTextField textField_CMNo;
	private JTextField textField_CWNo;
	private JTextField textField_CHNo;
	private JTextField textField_CAID;
	private JTextField textField_CL;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addcust frame = new addcust();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void display() {
		try {
			addcust frame = new addcust();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Create the frame.
	 */
	public addcust() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 519, 327);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Adding a Customer");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel.setBounds(150, 11, 199, 35);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Please enter the following informantion about the cutomer");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(73, 56, 401, 19);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2_CustName = new JLabel("Name");
		lblNewLabel_2_CustName.setBounds(25, 115, 49, 25);
		contentPane.add(lblNewLabel_2_CustName);
		
		textField_CName = new JTextField();
		textField_CName.setBounds(84, 117, 96, 20);
		contentPane.add(textField_CName);
		textField_CName.setColumns(10);
		
		JLabel lblNewLabel_2_CID = new JLabel("ID");
		lblNewLabel_2_CID.setBounds(25, 90, 49, 14);
		contentPane.add(lblNewLabel_2_CID);
		
		textField_CID = new JTextField();
		textField_CID.setBounds(84, 86, 96, 20);
		contentPane.add(textField_CID);
		textField_CID.setColumns(10);
		
		JLabel lblNewLabel_2_CAge = new JLabel("Age");
		lblNewLabel_2_CAge.setBounds(25, 151, 49, 14);
		contentPane.add(lblNewLabel_2_CAge);
		
		textField_CAge = new JTextField();
		textField_CAge.setBounds(84, 148, 96, 20);
		contentPane.add(textField_CAge);
		textField_CAge.setColumns(10);
		
		JLabel lblNewLabel_2_Sex = new JLabel("Sex");
		lblNewLabel_2_Sex.setBounds(25, 182, 49, 14);
		contentPane.add(lblNewLabel_2_Sex);
		
		textField_CSex = new JTextField();
		textField_CSex.setBounds(84, 179, 96, 20);
		contentPane.add(textField_CSex);
		textField_CSex.setColumns(10);
		
		JLabel lblNewLabel_2_CMNo = new JLabel("Mobile Number");
		lblNewLabel_2_CMNo.setBounds(229, 120, 104, 14);
		contentPane.add(lblNewLabel_2_CMNo);
		
		textField_CMNo = new JTextField();
		textField_CMNo.setBounds(378, 117, 96, 20);
		contentPane.add(textField_CMNo);
		textField_CMNo.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Work Number");
		lblNewLabel_2.setBounds(229, 151, 109, 14);
		contentPane.add(lblNewLabel_2);
		
		textField_CWNo = new JTextField();
		textField_CWNo.setBounds(378, 148, 96, 20);
		contentPane.add(textField_CWNo);
		textField_CWNo.setColumns(10);
		
		JLabel lblNewLabel_3_HNo = new JLabel("Home Number");
		lblNewLabel_3_HNo.setBounds(229, 92, 114, 14);
		contentPane.add(lblNewLabel_3_HNo);
		
		textField_CHNo = new JTextField();
		textField_CHNo.setBounds(378, 87, 96, 20);
		contentPane.add(textField_CHNo);
		textField_CHNo.setColumns(10);
		
		JLabel lblNewLabel_3_CAID = new JLabel("Agent ID");
		lblNewLabel_3_CAID.setBounds(229, 182, 96, 14);
		contentPane.add(lblNewLabel_3_CAID);
		
		textField_CAID = new JTextField();
		textField_CAID.setBounds(378, 179, 96, 20);
		contentPane.add(textField_CAID);
		textField_CAID.setColumns(10);
		
		JLabel lblNewLabel_3_CL = new JLabel("Link");
		lblNewLabel_3_CL.setBounds(150, 221, 49, 14);
		contentPane.add(lblNewLabel_3_CL);
		
		textField_CL = new JTextField();
		textField_CL.setBounds(247, 218, 96, 20);
		contentPane.add(textField_CL);
		textField_CL.setColumns(10);
		
		//Enter Button
		JButton btnNewButton_Enter = new JButton("Enter");
		btnNewButton_Enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				allmethods allM = new allmethods();
				int id = Integer.parseInt(textField_CID.getText());
				int age = Integer.parseInt(textField_CAge.getText());
				int mobileNo = Integer.parseInt(textField_CMNo.getText());
				int workNo = Integer.parseInt(textField_CWNo.getText());
				int homeNo = Integer.parseInt(textField_CHNo.getText());
				int agentId = Integer.parseInt(textField_CAID.getText());
				allM.addcust(id, textField_CName.getText(), age , textField_CSex.getText(), mobileNo, workNo, homeNo, agentId,textField_CL.getText());
			}
		});
		btnNewButton_Enter.setBounds(114, 256, 89, 23);
		contentPane.add(btnNewButton_Enter);
		
		//Reset Button
		JButton btnNewButton = new JButton("Reset");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_CID.setText("");
				textField_CName.setText("");
				textField_CAge.setText("");
				textField_CSex.setText("");
				textField_CMNo.setText("");
				textField_CWNo.setText("");
				textField_CHNo.setText("");
				textField_CAID.setText("");
				textField_CL.setText("");
			}
		});
		btnNewButton.setBounds(229, 256, 89, 23);
		contentPane.add(btnNewButton);
		
		//Exit Button
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(352, 256, 89, 23);
		contentPane.add(btnNewButton_1);
		
		
		
	}
}
