package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/*
 * Tamara Alasmar – 202103791
 * Saeeda Al-Marri – 202106704
 * Iman Khabaz –   202206112
 */

public class makeReservation extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField Reserve_notextField;
	private JTextField AIDtextField;
	private JTextField Package_notextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					makeReservation frame = new makeReservation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void display() {
		try {
			addcust frame = new addcust();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public makeReservation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Make a Resvervation  ");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel.setBounds(106, 24, 282, 34);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("   for the recently added customer");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(86, 43, 300, 50);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Reserveation Number");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(70, 104, 153, 14);
		contentPane.add(lblNewLabel_2);
		
		Reserve_notextField = new JTextField();
		Reserve_notextField.setBounds(275, 101, 96, 20);
		contentPane.add(Reserve_notextField);
		Reserve_notextField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Agent ID");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(70, 137, 96, 28);
		contentPane.add(lblNewLabel_3);
		
		AIDtextField = new JTextField();
		AIDtextField.setBounds(275, 143, 96, 20);
		contentPane.add(AIDtextField);
		AIDtextField.setColumns(10);
		
		Package_notextField = new JTextField();
		Package_notextField.setBounds(275, 174, 96, 20);
		contentPane.add(Package_notextField);
		Package_notextField.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Package Number");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(70, 176, 153, 14);
		contentPane.add(lblNewLabel_4);
		
		//Enter Button
		JButton btnNewButton = new JButton("Enter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				allmethods allM = new allmethods();
				int rn = Integer.parseInt(Reserve_notextField.getText());
				int AId = Integer.parseInt(AIDtextField.getText());
				int pn = Integer.parseInt(Package_notextField.getText());
				allM.addReservation(rn, AId, pn);
			}
		});
		btnNewButton.setBounds(86, 229, 89, 23);
		contentPane.add(btnNewButton);
		
		//Reset Button
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reserve_notextField.setText("");
				AIDtextField.setText("");
				Package_notextField.setText("");
			}
		});
		btnNewButton_1.setBounds(185, 229, 89, 23);
		contentPane.add(btnNewButton_1);
		
		//Exit Button
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_2.setBounds(282, 229, 89, 23);
		contentPane.add(btnNewButton_2);
	}
}
