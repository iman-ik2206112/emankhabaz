package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
/*
 * Tamara Alasmar – 202103791
 * Saeeda Al-Marri – 202106704
 * Iman Khabaz –   202206112
 */

public class QTA_ extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField usernametxt;
	private JTextField passwordtxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QTA_ frame = new QTA_();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public QTA_() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to QTA Website");
		lblNewLabel.setFont(new Font("Tahoma", Font.ITALIC, 26));
		lblNewLabel.setBounds(10, 10, 379, 43);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("please Enter your username and password");
		lblNewLabel_1.setFont(new Font("Sylfaen", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(10, 63, 369, 27);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("username");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(10, 112, 70, 13);
		contentPane.add(lblNewLabel_2);
		
		usernametxt = new JTextField();
		usernametxt.setBounds(114, 110, 96, 19);
		contentPane.add(usernametxt);
		usernametxt.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("password");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_3.setBounds(10, 164, 82, 13);
		contentPane.add(lblNewLabel_3);
		
		passwordtxt = new JTextField();
		passwordtxt.setBounds(114, 162, 96, 19);
		contentPane.add(passwordtxt);
		passwordtxt.setColumns(10);
		
		//Continue Button
		JButton CButton = new JButton("continue");
		CButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String un = usernametxt.getText();
				int pw = Integer.parseInt(passwordtxt.getText());
				Connection conn ;
				
				try {
					conn = DriverManager.getConnection("jdbc:oracle:thin:@coestudb.qu.edu.qa:1521/STUD.qu.edu.qa" , "ik2206112" , "ik2206112");
					PreparedStatement stmt = conn.prepareStatement("select * from login_agent where username = ?  and  password_=?");
					stmt.setString(1, un);
					stmt.setInt(2, pw);
					ResultSet rs = stmt.executeQuery();
					if(rs.next()) {
						JOptionPane.showMessageDialog(null, "Login Successfully");
						Menu m = new Menu();
						m.run2();}
					else
						JOptionPane.showMessageDialog(null, "Invalid username/password");
					conn.close();
					stmt.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}		
			}
		});
		CButton.setBounds(70, 233, 89, 23);
		contentPane.add(CButton);
		
		//Reset Button
		JButton ResetButton = new JButton("Reset");
		ResetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				usernametxt.setText("");
				passwordtxt.setText("");

			}
		});
		ResetButton.setBounds(173, 233, 89, 23);
		contentPane.add(ResetButton);
		
		//Exit Button
		JButton ExitButton = new JButton("Exit");
		ExitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		ExitButton.setBounds(272, 233, 89, 23);
		contentPane.add(ExitButton);
		
	}
}
