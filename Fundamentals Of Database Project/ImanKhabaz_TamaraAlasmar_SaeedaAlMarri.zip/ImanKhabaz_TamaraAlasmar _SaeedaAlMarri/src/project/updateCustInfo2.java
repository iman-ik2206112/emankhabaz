package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/*
 * Tamara Alasmar – 202103791
 * Saeeda Al-Marri – 202106704
 * Iman Khabaz –   202206112
 */

public class updateCustInfo2 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_CName;
	private JTextField textField_CAge;
	private JTextField textField_CSex;
	private JTextField textField_CMNo;
	private JTextField textField_CWNo;
	private JTextField textField_CHNo;
	private JTextField textField_CAID;
	private JTextField textField_CL;
	private JTextField IDtextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					updateCustInfo2 frame = new updateCustInfo2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void display() {
		try {
			updateCustInfo2 frame = new updateCustInfo2();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Create the frame.
	 */
	public updateCustInfo2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 687, 432);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Updating Customer Information");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel.setBounds(154, 11, 402, 35);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Customer ID that you want to update");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(93, 61, 341, 39);
		contentPane.add(lblNewLabel_1);
		
		
		JLabel lblNewLabel_11 = new JLabel("Please enter the following new informantion about the cutomer");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_11.setBounds(93, 121, 432, 19);
		contentPane.add(lblNewLabel_11);
		
		JLabel lblNewLabel_2_CustName = new JLabel("Name");
		lblNewLabel_2_CustName.setBounds(42, 149, 49, 25);
		contentPane.add(lblNewLabel_2_CustName);
		
		textField_CName = new JTextField();
		textField_CName.setBounds(137, 151, 96, 20);
		contentPane.add(textField_CName);
		textField_CName.setColumns(10);
		
		JLabel lblNewLabel_2_CAge = new JLabel("Age");
		lblNewLabel_2_CAge.setBounds(42, 185, 49, 14);
		contentPane.add(lblNewLabel_2_CAge);
		
		textField_CAge = new JTextField();
		textField_CAge.setBounds(137, 182, 96, 20);
		contentPane.add(textField_CAge);
		textField_CAge.setColumns(10);
		
		JLabel lblNewLabel_2_Sex = new JLabel("Sex");
		lblNewLabel_2_Sex.setBounds(42, 224, 49, 14);
		contentPane.add(lblNewLabel_2_Sex);
		
		textField_CSex = new JTextField();
		textField_CSex.setBounds(137, 221, 96, 20);
		contentPane.add(textField_CSex);
		textField_CSex.setColumns(10);
		
		JLabel lblNewLabel_2_CMNo = new JLabel("Mobile Number");
		lblNewLabel_2_CMNo.setBounds(327, 185, 104, 14);
		contentPane.add(lblNewLabel_2_CMNo);
		
		textField_CMNo = new JTextField();
		textField_CMNo.setBounds(460, 182, 96, 20);
		contentPane.add(textField_CMNo);
		textField_CMNo.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Work Number");
		lblNewLabel_2.setBounds(332, 224, 109, 14);
		contentPane.add(lblNewLabel_2);
		
		textField_CWNo = new JTextField();
		textField_CWNo.setBounds(460, 221, 96, 20);
		contentPane.add(textField_CWNo);
		textField_CWNo.setColumns(10);
		
		JLabel lblNewLabel_3_HNo = new JLabel("Home Number");
		lblNewLabel_3_HNo.setBounds(327, 160, 114, 14);
		contentPane.add(lblNewLabel_3_HNo);
		
		textField_CHNo = new JTextField();
		textField_CHNo.setBounds(460, 151, 96, 20);
		contentPane.add(textField_CHNo);
		textField_CHNo.setColumns(10);
		
		JLabel lblNewLabel_3_CAID = new JLabel("Agent ID");
		lblNewLabel_3_CAID.setBounds(41, 268, 96, 14);
		contentPane.add(lblNewLabel_3_CAID);
		
		textField_CAID = new JTextField();
		textField_CAID.setBounds(137, 265, 96, 20);
		contentPane.add(textField_CAID);
		textField_CAID.setColumns(10);
		
		JLabel lblNewLabel_3_CL = new JLabel("Link");
		lblNewLabel_3_CL.setBounds(335, 268, 49, 14);
		contentPane.add(lblNewLabel_3_CL);
		
		textField_CL = new JTextField();
		textField_CL.setBounds(460, 265, 96, 20);
		contentPane.add(textField_CL);
		textField_CL.setColumns(10);
		
		IDtextField = new JTextField();
		IDtextField.setBounds(403, 67, 122, 29);
		contentPane.add(IDtextField);
		IDtextField.setColumns(10);
		
		//Enter Button
		JButton btnNewButton_Enter = new JButton("Enter");
		btnNewButton_Enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				allmethods allM = new allmethods();
				int customerID = Integer.parseInt(IDtextField.getText());
				int age = Integer.parseInt(textField_CAge.getText());
				int mobileNo = Integer.parseInt(textField_CMNo.getText());
				int workNo = Integer.parseInt(textField_CWNo.getText());
				int homeNo = Integer.parseInt(textField_CHNo.getText());
				int agentId = Integer.parseInt(textField_CAID.getText());
				allM.updatecust(customerID,textField_CName.getText(), age , textField_CSex.getText(), mobileNo, workNo, homeNo, agentId,textField_CL.getText());
			}
		});
		btnNewButton_Enter.setBounds(137, 314, 89, 23);
		contentPane.add(btnNewButton_Enter);
		
		//Reset Button
		JButton btnNewButton = new JButton("Reset");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IDtextField.setText("");
				textField_CName.setText("");
				textField_CAge.setText("");
				textField_CSex.setText("");
				textField_CMNo.setText("");
				textField_CWNo.setText("");
				textField_CHNo.setText("");
				textField_CAID.setText("");
				textField_CL.setText("");
			}
		});
		btnNewButton.setBounds(306, 314, 89, 23);
		contentPane.add(btnNewButton);
		
		//Exit Button
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(460, 314, 89, 23);
		contentPane.add(btnNewButton_1);
		
		
		
		
		
	}


}
